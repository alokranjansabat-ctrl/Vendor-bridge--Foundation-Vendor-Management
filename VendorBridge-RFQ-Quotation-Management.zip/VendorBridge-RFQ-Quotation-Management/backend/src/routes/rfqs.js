import { Router } from 'express';
import RFQ from '../models/RFQ.js';
import Quotation from '../models/Quotation.js';
import { protect, allowRoles } from '../middleware/auth.js';

const router = Router();
router.use(protect);

router.get('/', async (req, res) => {
  const filter = req.user.role === 'buyer' ? { buyer: req.user._id } : { status: 'open', deadline: { $gte: new Date() } };
  const rfqs = await RFQ.find(filter).populate('buyer', 'name email').sort({ createdAt: -1 });
  res.json({ rfqs });
});

router.post('/', allowRoles('buyer'), async (req, res) => {
  const { title, description, category, quantity, unit, deliveryLocation, deadline } = req.body;
  if (!title || !description || !category || !quantity || !unit || !deliveryLocation || !deadline)
    return res.status(400).json({ message: 'Please complete all RFQ fields' });
  if (new Date(deadline) <= new Date()) return res.status(400).json({ message: 'Deadline must be in the future' });
  const rfq = await RFQ.create({ title, description, category, quantity, unit, deliveryLocation, deadline, buyer: req.user._id });
  res.status(201).json({ rfq });
});

router.get('/:id', async (req, res) => {
  const rfq = await RFQ.findById(req.params.id).populate('buyer', 'name email');
  if (!rfq) return res.status(404).json({ message: 'RFQ not found' });
  if (req.user.role === 'buyer' && !rfq.buyer._id.equals(req.user._id))
    return res.status(403).json({ message: 'Access denied' });
  res.json({ rfq });
});

router.put('/:id', allowRoles('buyer'), async (req, res) => {
  const rfq = await RFQ.findOne({ _id: req.params.id, buyer: req.user._id });
  if (!rfq) return res.status(404).json({ message: 'RFQ not found' });
  if (rfq.status !== 'open') return res.status(400).json({ message: 'Only open RFQs can be edited' });
  const fields = ['title', 'description', 'category', 'quantity', 'unit', 'deliveryLocation', 'deadline'];
  fields.forEach(key => { if (req.body[key] !== undefined) rfq[key] = req.body[key]; });
  await rfq.save();
  res.json({ rfq });
});

router.delete('/:id', allowRoles('buyer'), async (req, res) => {
  const rfq = await RFQ.findOneAndDelete({ _id: req.params.id, buyer: req.user._id, status: 'open' });
  if (!rfq) return res.status(404).json({ message: 'Open RFQ not found' });
  await Quotation.deleteMany({ rfq: rfq._id });
  res.json({ message: 'RFQ deleted' });
});

router.post('/:id/quotations', allowRoles('vendor'), async (req, res) => {
  const rfq = await RFQ.findById(req.params.id);
  if (!rfq || rfq.status !== 'open' || rfq.deadline <= new Date())
    return res.status(400).json({ message: 'This RFQ is not accepting quotations' });
  const { unitPrice, deliveryDays, notes } = req.body;
  if (unitPrice === undefined || !deliveryDays || Number(unitPrice) < 0)
    return res.status(400).json({ message: 'Valid unit price and delivery days are required' });
  const totalPrice = Number(unitPrice) * rfq.quantity;
  const quotation = await Quotation.create({
    rfq: rfq._id, vendor: req.user._id, unitPrice: Number(unitPrice),
    totalPrice, deliveryDays: Number(deliveryDays), notes
  });
  res.status(201).json({ quotation });
});

router.get('/:id/quotations', allowRoles('buyer'), async (req, res) => {
  const rfq = await RFQ.findOne({ _id: req.params.id, buyer: req.user._id });
  if (!rfq) return res.status(404).json({ message: 'RFQ not found' });
  const quotations = await Quotation.find({ rfq: rfq._id }).populate('vendor', 'name email').sort({ totalPrice: 1 });
  res.json({ quotations });
});

router.patch('/:id/award/:quotationId', allowRoles('buyer'), async (req, res) => {
  const rfq = await RFQ.findOne({ _id: req.params.id, buyer: req.user._id });
  if (!rfq) return res.status(404).json({ message: 'RFQ not found' });
  const selected = await Quotation.findOne({ _id: req.params.quotationId, rfq: rfq._id });
  if (!selected) return res.status(404).json({ message: 'Quotation not found' });
  await Quotation.updateMany({ rfq: rfq._id }, [{ $set: { status: { $cond: [{ $eq: ['$_id', selected._id] }, 'awarded', 'rejected'] } } }]);
  rfq.status = 'awarded';
  rfq.awardedQuotation = selected._id;
  await rfq.save();
  res.json({ message: 'Quotation awarded', rfq });
});

export default router;
