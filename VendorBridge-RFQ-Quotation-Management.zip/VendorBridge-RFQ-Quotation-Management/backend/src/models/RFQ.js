import mongoose from 'mongoose';

const rfqSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 140 },
  description: { type: String, required: true, maxlength: 3000 },
  category: { type: String, required: true, trim: true },
  quantity: { type: Number, required: true, min: 1 },
  unit: { type: String, required: true, trim: true },
  deliveryLocation: { type: String, required: true, trim: true },
  deadline: { type: Date, required: true },
  status: { type: String, enum: ['open', 'closed', 'awarded'], default: 'open' },
  buyer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  awardedQuotation: { type: mongoose.Schema.Types.ObjectId, ref: 'Quotation', default: null }
}, { timestamps: true });

export default mongoose.model('RFQ', rfqSchema);
