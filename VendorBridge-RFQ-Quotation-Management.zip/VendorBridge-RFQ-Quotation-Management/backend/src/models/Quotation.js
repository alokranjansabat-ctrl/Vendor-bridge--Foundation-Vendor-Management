import mongoose from 'mongoose';

const quotationSchema = new mongoose.Schema({
  rfq: { type: mongoose.Schema.Types.ObjectId, ref: 'RFQ', required: true },
  vendor: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  unitPrice: { type: Number, required: true, min: 0 },
  totalPrice: { type: Number, required: true, min: 0 },
  deliveryDays: { type: Number, required: true, min: 1 },
  notes: { type: String, maxlength: 1500, default: '' },
  status: { type: String, enum: ['submitted', 'awarded', 'rejected'], default: 'submitted' }
}, { timestamps: true });

quotationSchema.index({ rfq: 1, vendor: 1 }, { unique: true });
export default mongoose.model('Quotation', quotationSchema);
