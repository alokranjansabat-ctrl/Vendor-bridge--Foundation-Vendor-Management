import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import mongoose from 'mongoose';
import './config/db.js';
import authRoutes from './routes/auth.js';
import rfqRoutes from './routes/rfqs.js';
import { notFound, errorHandler } from './middleware/errors.js';

const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5173' }));
app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));
app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, limit: 300 }));
app.get('/api/health', (_req, res) => res.json({ status: 'ok', service: 'VendorBridge API' }));
app.use('/api/auth', authRoutes);
app.use('/api/rfqs', rfqRoutes);
app.use(notFound);
app.use(errorHandler);

const port = process.env.PORT || 5000;
mongoose.connection.once('open', () => {
  app.listen(port, () => console.log(`VendorBridge API running on port ${port}`));
});
mongoose.connection.on('error', err => console.error('MongoDB connection error:', err.message));
