import React, { useEffect, useMemo, useState } from 'react';
import { ArrowRight, FileText, LogOut, Plus, Search, ShieldCheck, Truck, X } from 'lucide-react';
import { getToken, request } from './api';

const money = n => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(n || 0);
const blankRFQ = { title:'', description:'', category:'', quantity:1, unit:'pieces', deliveryLocation:'', deadline:'' };

export default function App() {
  const [token, setToken] = useState(getToken());
  const [user, setUser] = useState(null);
  const [authMode, setAuthMode] = useState('login');
  const [auth, setAuth] = useState({ name:'', email:'', password:'', role:'buyer' });
  const [rfqs, setRfqs] = useState([]);
  const [selected, setSelected] = useState(null);
  const [quotes, setQuotes] = useState([]);
  const [form, setForm] = useState(blankRFQ);
  const [quoteForm, setQuoteForm] = useState({ unitPrice:'', deliveryDays:7, notes:'' });
  const [showCreate, setShowCreate] = useState(false);
  const [search, setSearch] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');

  async function load() {
    const me = await request('/auth/me');
    setUser(me.user);
    const data = await request('/rfqs');
    setRfqs(data.rfqs);
  }
  useEffect(() => { if (token) load().catch(e => { setMessage(e.message); logout(); }); }, [token]);

  function logout() {
    localStorage.removeItem('vb_token'); setToken(null); setUser(null); setRfqs([]); setSelected(null);
  }
  async function authenticate(e) {
    e.preventDefault(); setBusy(true); setMessage('');
    try {
      const data = await request(`/auth/${authMode}`, { method:'POST', body:JSON.stringify(auth) });
      localStorage.setItem('vb_token', data.token); setToken(data.token); setUser(data.user);
    } catch(e) { setMessage(e.message); } finally { setBusy(false); }
  }
  async function createRFQ(e) {
    e.preventDefault(); setBusy(true);
    try {
      await request('/rfqs', { method:'POST', body:JSON.stringify(form) });
      setForm(blankRFQ); setShowCreate(false); setMessage('RFQ published successfully.'); await load();
    } catch(e) { setMessage(e.message); } finally { setBusy(false); }
  }
  async function openRFQ(rfq) {
    setSelected(rfq); setMessage('');
    if (user.role === 'buyer') {
      try { const data = await request(`/rfqs/${rfq._id}/quotations`); setQuotes(data.quotations); }
      catch(e) { setMessage(e.message); }
    }
  }
  async function submitQuote(e) {
    e.preventDefault(); setBusy(true);
    try {
      await request(`/rfqs/${selected._id}/quotations`, { method:'POST', body:JSON.stringify(quoteForm) });
      setMessage('Your quotation has been submitted.'); setSelected(null); setQuoteForm({ unitPrice:'', deliveryDays:7, notes:'' });
    } catch(e) { setMessage(e.message); } finally { setBusy(false); }
  }
  async function award(id) {
    try {
      await request(`/rfqs/${selected._id}/award/${id}`, { method:'PATCH' });
      setMessage('Quotation awarded successfully.'); setSelected(null); await load();
    } catch(e) { setMessage(e.message); }
  }
  const filtered = useMemo(() => rfqs.filter(r => `${r.title} ${r.category} ${r.deliveryLocation}`.toLowerCase().includes(search.toLowerCase())), [rfqs, search]);

  if (!token || !user) return <div className="auth-page"><div className="auth-card">
    <div className="brand-mark">VB</div><p className="eyebrow">PROCUREMENT MADE SIMPLE</p><h1>Welcome to VendorBridge</h1>
    <p className="muted">Connect buyers and vendors. Request, compare and award quotations in one place.</p>
    {message && <div className="notice">{message}</div>}
    <form onSubmit={authenticate} className="form-stack">
      {authMode === 'register' && <label>Full name<input required value={auth.name} onChange={e=>setAuth({...auth,name:e.target.value})} placeholder="Your name"/></label>}
      <label>Email address<input required type="email" value={auth.email} onChange={e=>setAuth({...auth,email:e.target.value})} placeholder="you@example.com"/></label>
      <label>Password<input required minLength="8" type="password" value={auth.password} onChange={e=>setAuth({...auth,password:e.target.value})} placeholder="At least 8 characters"/></label>
      {authMode === 'register' && <label>Account type<select value={auth.role} onChange={e=>setAuth({...auth,role:e.target.value})}><option value="buyer">Buyer</option><option value="vendor">Vendor</option></select></label>}
      <button className="primary" disabled={busy}>{busy?'Please wait…':authMode==='login'?'Sign in':'Create account'} <ArrowRight size={17}/></button>
    </form>
    <p className="switch">{authMode==='login'?'New to VendorBridge?':'Already registered?'} <button onClick={()=>{setAuthMode(authMode==='login'?'register':'login');setMessage('')}}>{authMode==='login'?'Create an account':'Sign in'}</button></p>
  </div></div>;

  return <div className="app-shell">
    <aside className="sidebar"><div className="logo"><span>VB</span><b>VendorBridge</b></div><div className="side-label">WORKSPACE</div>
      <div className="nav-item active"><FileText size={18}/> {user.role==='buyer'?'My RFQs':'Open RFQs'}</div>
      <div className="side-bottom"><div className="user-chip"><div className="avatar">{user.name?.[0]?.toUpperCase()}</div><div><b>{user.name}</b><small>{user.role}</small></div></div><button className="logout" onClick={logout}><LogOut size={17}/> Sign out</button></div>
    </aside>
    <main className="main"><header className="topbar"><div><p className="eyebrow">VENDOR PROCUREMENT PORTAL</p><h2>{user.role==='buyer'?'RFQ Management':'Discover Opportunities'}</h2></div><div className="role-pill"><ShieldCheck size={15}/>{user.role}</div></header>
      <section className="welcome"><div><h1>{user.role==='buyer'?'Manage sourcing with confidence.':'Find your next business opportunity.'}</h1><p>{user.role==='buyer'?'Create requests, review vendor offers and award the right quotation.':'Browse active requests and send competitive quotations to buyers.'}</p></div><div className="welcome-icon"><Truck size={42}/></div></section>
      {message && <div className="notice dismiss"><span>{message}</span><button onClick={()=>setMessage('')}><X size={16}/></button></div>}
      <div className="toolbar"><div className="search"><Search size={18}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search RFQs by title, category or location…"/></div>{user.role==='buyer'&&<button className="primary create-btn" onClick={()=>setShowCreate(true)}><Plus size={18}/> Create RFQ</button>}</div>
      <div className="section-heading"><div><h3>{user.role==='buyer'?'Your requests':'Available requests'}</h3><p>{filtered.length} request{filtered.length===1?'':'s'} found</p></div></div>
      {filtered.length===0?<div className="empty"><FileText size={34}/><h3>No RFQs found</h3><p>{search?'Try another search term.':'New requests will appear here.'}</p></div>:<div className="rfq-grid">{filtered.map(r=><article className="rfq-card" key={r._id}><div className="card-top"><span className="category">{r.category}</span><span className={`status ${r.status}`}>{r.status}</span></div><h3>{r.title}</h3><p className="description">{r.description}</p><div className="meta"><span>Quantity</span><b>{r.quantity} {r.unit}</b><span>Delivery to</span><b>{r.deliveryLocation}</b><span>Deadline</span><b>{new Date(r.deadline).toLocaleDateString()}</b></div><button className="text-btn" onClick={()=>openRFQ(r)}>View details <ArrowRight size={16}/></button></article>)}</div>}
    </main>

    {showCreate&&<div className="overlay" onClick={()=>setShowCreate(false)}><div className="modal" onClick={e=>e.stopPropagation()}><div className="modal-head"><div><p className="eyebrow">NEW PROCUREMENT REQUEST</p><h2>Create an RFQ</h2></div><button className="icon-btn" onClick={()=>setShowCreate(false)}><X/></button></div><form onSubmit={createRFQ} className="form-grid">
      <label className="wide">RFQ title<input required maxLength="140" value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="e.g. Office chairs procurement"/></label>
      <label>Category<input required value={form.category} onChange={e=>setForm({...form,category:e.target.value})} placeholder="Furniture"/></label><label>Quantity<input required min="1" type="number" value={form.quantity} onChange={e=>setForm({...form,quantity:e.target.value})}/></label>
      <label>Unit<input required value={form.unit} onChange={e=>setForm({...form,unit:e.target.value})} placeholder="pieces"/></label><label>Delivery location<input required value={form.deliveryLocation} onChange={e=>setForm({...form,deliveryLocation:e.target.value})} placeholder="City, State"/></label>
      <label>Submission deadline<input required type="datetime-local" value={form.deadline} onChange={e=>setForm({...form,deadline:e.target.value})}/></label>
      <label className="wide">Description<textarea required rows="4" value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Describe specifications, quality requirements and other details…"/></label>
      <div className="wide modal-actions"><button type="button" className="secondary" onClick={()=>setShowCreate(false)}>Cancel</button><button className="primary" disabled={busy}>Publish RFQ <ArrowRight size={16}/></button></div>
    </form></div></div>}

    {selected&&<div className="overlay" onClick={()=>setSelected(null)}><div className="modal detail-modal" onClick={e=>e.stopPropagation()}><div className="modal-head"><div><p className="eyebrow">REQUEST DETAILS</p><h2>{selected.title}</h2></div><button className="icon-btn" onClick={()=>setSelected(null)}><X/></button></div>
      <span className="category">{selected.category}</span><p className="detail-description">{selected.description}</p><div className="detail-stats"><div><small>Quantity</small><b>{selected.quantity} {selected.unit}</b></div><div><small>Delivery location</small><b>{selected.deliveryLocation}</b></div><div><small>Deadline</small><b>{new Date(selected.deadline).toLocaleString()}</b></div></div>
      {user.role==='vendor'?<form className="form-stack quote-form" onSubmit={submitQuote}><h3>Submit your quotation</h3><label>Unit price (₹)<input required min="0" step="0.01" type="number" value={quoteForm.unitPrice} onChange={e=>setQuoteForm({...quoteForm,unitPrice:e.target.value})}/></label><label>Delivery time (days)<input required min="1" type="number" value={quoteForm.deliveryDays} onChange={e=>setQuoteForm({...quoteForm,deliveryDays:e.target.value})}/></label><label>Notes<textarea rows="3" value={quoteForm.notes} onChange={e=>setQuoteForm({...quoteForm,notes:e.target.value})} placeholder="Add terms, warranty or clarifications…"/></label><button className="primary" disabled={busy}>Send quotation <ArrowRight size={16}/></button></form>:<div className="quotes"><h3>Vendor quotations ({quotes.length})</h3>{quotes.length===0?<p className="muted">No quotations have been submitted yet.</p>:quotes.map(q=><div className="quote-row" key={q._id}><div><b>{q.vendor?.name}</b><small>{q.deliveryDays} days · {q.status}</small><p>{q.notes}</p></div><div className="quote-price"><b>{money(q.totalPrice)}</b><small>{money(q.unitPrice)} / {selected.unit}</small>{q.status==='submitted'&&selected.status==='open'&&<button className="small-primary" onClick={()=>award(q._id)}>Award</button>}</div></div>)}</div>}
    </div></div>}
  </div>;
}
